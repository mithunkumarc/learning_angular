import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cibil-report',
  templateUrl: './cibil-report.component.html',
  styleUrls: ['./cibil-report.component.css']
})
export class CibilReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
