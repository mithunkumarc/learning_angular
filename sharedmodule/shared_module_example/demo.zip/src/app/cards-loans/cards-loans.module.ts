import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplyOnlineComponent } from './apply-online/apply-online.component';
import { CardsLoansRoutingModule } from './cards-loans-routing.module';
import { CibilReportComponent } from './cibil-report/cibil-report.component';
import { LoansComponent } from './loans/loans.component';


@NgModule({
  declarations: [ApplyOnlineComponent, CibilReportComponent, LoansComponent],
  imports: [
    CommonModule,
    CardsLoansRoutingModule
  ]
})
export class CardsLoansModule { }
