import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-online',
  templateUrl: './apply-online.component.html',
  styleUrls: ['./apply-online.component.css']
})
export class ApplyOnlineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
