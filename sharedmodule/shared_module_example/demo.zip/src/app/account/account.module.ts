import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepositsComponent } from './deposits/deposits.component';
import { AccountRoutingModule } from './account-routing.module';
import { PpfaccountComponent } from './ppfaccount/ppfaccount.component';
import { SsyAccountComponent } from './ssy-account/ssy-account.component';



@NgModule({
    declarations: [DepositsComponent, PpfaccountComponent, SsyAccountComponent],
    imports: [
        CommonModule,
        AccountRoutingModule
    ]
})
export class AccountModule{

}