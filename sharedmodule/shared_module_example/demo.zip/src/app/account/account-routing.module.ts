import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepositsComponent } from './deposits/deposits.component';
import { PpfaccountComponent } from './ppfaccount/ppfaccount.component';
import { SsyAccountComponent } from './ssy-account/ssy-account.component';

const routes: Routes = [
    {
        path: 'DepositsComponent', component: DepositsComponent,
    },
    {
        path: 'PpfAccount', component: PpfaccountComponent,
    },
    {
        path: 'SsyAccount', component: SsyAccountComponent
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports:[RouterModule]
})
export class AccountRoutingModule {}