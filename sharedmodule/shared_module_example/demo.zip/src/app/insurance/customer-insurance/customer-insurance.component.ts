import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-insurance',
  templateUrl: './customer-insurance.component.html',
  styleUrls: ['./customer-insurance.component.css']
})
export class CustomerInsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
