import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demat',
  templateUrl: './demat.component.html',
  styleUrls: ['./demat.component.css']
})
export class DematComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
