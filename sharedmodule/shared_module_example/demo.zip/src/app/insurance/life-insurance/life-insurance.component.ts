import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-life-insurance',
  templateUrl: './life-insurance.component.html',
  styleUrls: ['./life-insurance.component.css']
})
export class LifeInsuranceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
