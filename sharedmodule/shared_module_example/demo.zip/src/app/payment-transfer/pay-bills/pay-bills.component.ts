import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-bills',
  templateUrl: './pay-bills.component.html',
  styleUrls: ['./pay-bills.component.css']
})
export class PayBillsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
