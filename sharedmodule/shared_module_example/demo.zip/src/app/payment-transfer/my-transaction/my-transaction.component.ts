import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-transaction',
  templateUrl: './my-transaction.component.html',
  styleUrls: ['./my-transaction.component.css']
})
export class MyTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
