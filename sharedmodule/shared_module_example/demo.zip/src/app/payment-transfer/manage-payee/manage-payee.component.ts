import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-payee',
  templateUrl: './manage-payee.component.html',
  styleUrls: ['./manage-payee.component.css']
})
export class ManagePayeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
