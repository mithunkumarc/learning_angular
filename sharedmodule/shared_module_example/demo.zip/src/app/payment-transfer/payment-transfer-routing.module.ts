import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyTransactionComponent } from './my-transaction/my-transaction.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { ManagePayeeComponent } from './manage-payee/manage-payee.component';
import { PayBillsComponent } from './pay-bills/pay-bills.component';

const routes: Routes = [
    {
        path: "MyTransactionComponent", component: MyTransactionComponent
    },
    {
        path: "FundTransferComponent", component: FundTransferComponent
    },
    {
        path: "PayBillsComponent", component: PayBillsComponent
    },
    {
        path: "ManagePayeeComponent", component: ManagePayeeComponent
    }
]


@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PaymentTransferRoutingModule {

}