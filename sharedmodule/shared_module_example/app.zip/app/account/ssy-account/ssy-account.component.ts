import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ssy-account',
  templateUrl: './ssy-account.component.html',
  styleUrls: ['./ssy-account.component.css']
})
export class SsyAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
