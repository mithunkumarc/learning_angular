import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppfaccount',
  templateUrl: './ppfaccount.component.html',
  styleUrls: ['./ppfaccount.component.css']
})
export class PpfaccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
