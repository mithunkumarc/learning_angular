import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PpfaccountComponent } from './ppfaccount.component';

describe('PpfaccountComponent', () => {
  let component: PpfaccountComponent;
  let fixture: ComponentFixture<PpfaccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PpfaccountComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PpfaccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
