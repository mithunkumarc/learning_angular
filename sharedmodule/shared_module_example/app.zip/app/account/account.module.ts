import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepositsComponent } from './deposits/deposits.component';
import { AccountRoutingModule } from './account-routing.module';
import { PpfaccountComponent } from './ppfaccount/ppfaccount.component';
import { SsyAccountComponent } from './ssy-account/ssy-account.component';
import { SharedModule } from './../shared/shared.module';


@NgModule({
    declarations: [DepositsComponent, PpfaccountComponent, SsyAccountComponent],
    imports: [
        CommonModule,
        AccountRoutingModule,
        SharedModule
    ]
})
export class AccountModule{

}