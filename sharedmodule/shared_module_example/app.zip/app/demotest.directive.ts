import { Directive, ElementRef, Input, OnInit} from '@angular/core';

@Directive({
    selector: '[demo-test-directive]'
})
export class DemoTestDirective implements OnInit{
    defaultColor = 'green';
    @Input()
    highLightColor: string;
    constructor(public el: ElementRef) {
        
    }

    ngOnInit() {
        this.el.nativeElement.style.backgroundColor = this.defaultColor;
        this.el.nativeElement.style.color = 'white';
    }
}