import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplyOnlineComponent } from './apply-online/apply-online.component';
import { CardsLoansRoutingModule } from './cards-loans-routing.module';
import { CibilReportComponent } from './cibil-report/cibil-report.component';
import { LoansComponent } from './loans/loans.component';
import { SharedModule } from './../shared/shared.module';

@NgModule({
  declarations: [ApplyOnlineComponent, CibilReportComponent, LoansComponent],
  imports: [
    CommonModule,
    CardsLoansRoutingModule,
    SharedModule
  ]
})
export class CardsLoansModule { }
