import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestDirective } from './test.directive';
import { DemoTestDirective } from './../demotest.directive';

@NgModule({
  declarations: [ TestDirective, DemoTestDirective ],
  imports: [
    CommonModule
  ],
  exports: [
    TestDirective,
    DemoTestDirective
  ]
})
export class SharedModule { }
