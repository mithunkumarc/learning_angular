import { Directive, ElementRef, Input, OnInit} from '@angular/core';

@Directive({
    selector: '[test-directive]'
})
export class TestDirective implements OnInit{
    defaultColor = 'yellow';
    @Input()
    highLightColor: string;
    constructor(public el: ElementRef) {
        
    }

    ngOnInit() {
        if(!this.highLightColor) {
            this.el.nativeElement.style.backgroundColor = this.defaultColor;
        } else {
            this.el.nativeElement.style.backgroundColor = this.highLightColor;
        }
    }
}