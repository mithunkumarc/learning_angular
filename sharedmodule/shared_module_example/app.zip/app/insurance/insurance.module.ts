import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LifeInsuranceComponent } from './life-insurance/life-insurance.component';
import { DematComponent } from './demat/demat.component';
import { CustomerInsuranceComponent } from './customer-insurance/customer-insurance.component';
import { BuyMutualFundComponent } from './buy-mutual-fund/buy-mutual-fund.component';
import { InsuranceRoutingModule } from './insurance-routing.module';
import { SharedModule } from './../shared/shared.module';

@NgModule({
  declarations: [LifeInsuranceComponent, DematComponent, CustomerInsuranceComponent, BuyMutualFundComponent],
  imports: [
    CommonModule, 
    InsuranceRoutingModule,
    SharedModule
  ]
})
export class InsuranceModule { }
