import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-mutual-fund',
  templateUrl: './buy-mutual-fund.component.html',
  styleUrls: ['./buy-mutual-fund.component.css']
})
export class BuyMutualFundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
